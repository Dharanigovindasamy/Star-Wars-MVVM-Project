package com.starwars.mvvm.constant

import androidx.room.TypeConverter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

object DateConverter {

    // Convert date string to timestamp
    @TypeConverter
    @JvmStatic
    fun dateToTimestamp(time: String?): Long? {
        val dateString = time
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'")
        dateFormat.timeZone = TimeZone.getTimeZone("UTC")

        return try {
            val date = dateFormat.parse(dateString)
            date?.time
        } catch (e: Exception) {
            null
        }
    }

    // Format timestamp to string with your desired format
    @JvmStatic
    fun formatTimestamp(timestamp: Long?): String {
        if (timestamp == null) {
            return ""
        }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        dateFormat.timeZone = TimeZone.getDefault()

        return dateFormat.format(Date(timestamp))
    }
}