package com.starwars.mvvm.ui

import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.starwars.mvvm.adapter.FilmDetailAdapter
import com.starwars.mvvm.constant.ListConverter
import com.starwars.mvvm.databinding.CharacterDetailFragmentBinding
import com.starwars.mvvm.viewModel.DetailFragmentViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DetailsFragment : Fragment() {

    private val args: DetailsFragmentArgs by navArgs()


    private lateinit var binding: CharacterDetailFragmentBinding
    private lateinit var filmAdapter: FilmDetailAdapter


    private val viewModel: DetailFragmentViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = CharacterDetailFragmentBinding.inflate(layoutInflater, container, false)

        getArgumentsFromNavigation()
        declareValue()
        setClickListener()
        fetchCharacterDetails()

        return binding.root
    }

    private fun fetchCharacterDetails() {
        lifecycleScope.launch {
            viewModel.moveDetail.observe(viewLifecycleOwner) {
                it?.let { it1 ->
                    Log.e("TAG", "onCreateView: ${it1.title}", )
                    filmAdapter.addItem(it1)
                }
            }
        }
    }

    private fun setClickListener() {
        binding.backBt.setOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun declareValue() {
        binding.characterName.text = args.character.name
        filmAdapter = FilmDetailAdapter()
        filmAdapter.stateRestorationPolicy = RecyclerView.Adapter.StateRestorationPolicy.PREVENT_WHEN_EMPTY
        binding.filmList.apply {
            val layoutManager: GridLayoutManager = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                GridLayoutManager(activity, 2)
            } else {
                GridLayoutManager(activity, 1)
            }
            this.layoutManager = layoutManager

            this.adapter = filmAdapter
            this.setHasFixedSize(true)
        }
    }

    private fun getArgumentsFromNavigation() {
        val filmLinks = ListConverter.fromString(args.character.filmList)
        filmLinks.forEach {
            extractFilmIdFromUrl(it)?.let { it1 -> viewModel.getFilms(it1) }
        }
    }

    private fun extractFilmIdFromUrl(url: String): Int? {
        val pattern = Regex("/films/(\\d+)/")
        val matchResult = pattern.find(url)
        return matchResult?.groups?.get(1)?.value?.toIntOrNull()
    }
}
