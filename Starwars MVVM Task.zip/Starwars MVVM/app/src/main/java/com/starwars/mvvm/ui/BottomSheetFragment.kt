package com.starwars.mvvm.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.starwars.mvvm.adapter.SortAdapter
import com.starwars.mvvm.databinding.FilterDialogBinding
import com.starwars.mvvm.viewModel.HomeFragmentViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BottomSheetFragment(private val homeViewModel: HomeFragmentViewModel) : BottomSheetDialogFragment() {

    private lateinit var binding: FilterDialogBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FilterDialogBinding.inflate(inflater, container, false)

        binding.sortFilterRecyclerView.apply {
            layoutManager = LinearLayoutManager(activity)
        }

        fetchFilmDetails()

        return binding.root
    }

    private fun fetchFilmDetails() {
        homeViewModel.updatedFilter.observe(viewLifecycleOwner, Observer { list ->
            binding.sortFilterRecyclerView.adapter = SortAdapter(list, SortAdapter.SortClickedListener { selectedFilter ->
                list.forEach {
                    if (it.isSelected) {
                        it.isSelected = false
                    }
                }
                selectedFilter.isSelected = !selectedFilter.isSelected
                homeViewModel.sort(selectedFilter)
                dismiss()
            })

        })
    }
}
