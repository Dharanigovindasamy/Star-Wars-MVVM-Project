package com.starwars.mvvm.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.starwars.mvvm.databinding.FilmChildItemBinding
import com.starwars.mvvm.modal.Film

class FilmDetailAdapter : RecyclerView.Adapter<FilmDetailAdapter.FilmDetailViewHolder>() {
    var list = mutableListOf<Film>()

    class FilmDetailViewHolder(private val binding: FilmChildItemBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(film: Film) {
            // Update the views directly using View Binding
            binding.filmTitle.text = film.title
            binding.directorName.text = film.director
            binding.producerName.text = film.producer.split(",").let {
                if (it.size >= 2) {
                    it.joinToString("\n")
                } else {
                    film.producer
                }
            }
            binding.releaseDate.text = film.release_date
        }

        companion object {
            fun from(parent: ViewGroup): FilmDetailViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = FilmChildItemBinding.inflate(layoutInflater, parent, false)
                return FilmDetailViewHolder(binding)
            }
        }
    }

    fun addItem(film: Film) {
        list.add(film)
        notifyItemInserted(list.size - 1)
    }

    override fun onBindViewHolder(holder: FilmDetailViewHolder, position: Int) {
        val item = list[position]
        item?.let {
            holder.bind(it)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmDetailViewHolder {
        return FilmDetailViewHolder.from(parent)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}

