package com.starwars.mvvm.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.starwars.mvvm.db.dao.CharacterDAO
import com.starwars.mvvm.db.dao.RemoteKeyDAO
import com.starwars.mvvm.db.entity.CharacterEntity
import com.starwars.mvvm.db.entity.CharacterRemoteKeyEntity


@Database(entities = [CharacterEntity::class,CharacterRemoteKeyEntity::class], version = 1)
abstract class CharacterDB : RoomDatabase() {

    abstract fun getCharacterDao() : CharacterDAO

    abstract fun getRemoteKeyDao() : RemoteKeyDAO
}