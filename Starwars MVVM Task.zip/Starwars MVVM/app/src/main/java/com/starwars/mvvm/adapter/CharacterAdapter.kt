package com.starwars.mvvm.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.starwars.mvvm.databinding.CharacterChildItemBinding
import com.starwars.mvvm.db.entity.CharacterEntity

class CharacterAdapter() :
    PagingDataAdapter<CharacterEntity, CharacterAdapter.CharacterViewHolder>(CHARACTER_COMPARATOR) {

    var onItemClick: ((CharacterEntity, CharacterChildItemBinding?, String, Int) -> Unit)? = null


    inner class CharacterViewHolder(private val binding: CharacterChildItemBinding) :
        RecyclerView.ViewHolder(binding.root) {


        fun bind(item: CharacterEntity) {

            binding.characterName.text = item.name
            binding.updatedDate.text = item.created.toString()
                binding.createdDate.text = item.edited.toString()
                binding.heightlabel.text = "Height"
                binding.genderLabel.text = "Gender"
                binding.weightLabel.text = "Weight"
                binding.charHeight.text = item.height.toString()
                binding.charGender.text = item.gender
                binding.charWeight.text = item.mass.toString()

            binding.cardLayout.setOnClickListener{
                onItemClick?.invoke(item, binding, "star", adapterPosition)

            }



        }


//            fun bind(character: CharacterEntity?) {
//            character?.let {
//                binding.characterName.text = it.name
//                binding.updatedDate.text = it.created.toString()
//                binding.createdDate.text = it.edited.toString()
//                binding.heightlabel.text = "Height"
//                binding.genderLabel.text = "Gender"
//                binding.weightLabel.text = "Weight"
//                binding.charHeight.text = it.height.toString()
//                binding.charGender.text = it.gender
//                binding.charWeight.text = it.mass.toString()
//
//                binding.root.setOnClickListener {
//                    Log.d("Clicked", "Character clicked")
//
//                  onItemClick!!.invoke(CharacterEntity(), binding,"edit",adapterPosition)
//
//
//
//                }
//            }
//        }

//        companion object {
//            fun from(parent: ViewGroup): CharacterViewHolder {
//                val inflater = LayoutInflater.from(parent.context)
//                val binding = CharacterChildItemBinding.inflate(inflater, parent, false)
//                return CharacterViewHolder(binding)
//            }
//        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {
        val binding = CharacterChildItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CharacterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }

    companion object {
        private val CHARACTER_COMPARATOR = object : DiffUtil.ItemCallback<CharacterEntity>() {
            override fun areItemsTheSame(oldItem: CharacterEntity, newItem: CharacterEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: CharacterEntity, newItem: CharacterEntity): Boolean {
                return oldItem == newItem
            }
        }
    }



 /*   class CharacterClickedListener(val clickListener: (character: CharacterEntity) -> Unit) {
        fun onClick(character: CharacterEntity) = clickListener(character)
    }*/
}
