package com.starwars.mvvm.constant

import com.starwars.mvvm.db.entity.CharacterEntity
import com.starwars.mvvm.modal.Character

object CharacterToEntityConverter {

     fun convertCharacterListToEntityList(characters: List<Character>): List<CharacterEntity> {
        return characters.map { convertModalToEntity(it) }
    }
     fun convertModalToEntity(character: Character): CharacterEntity {
         return CharacterEntity(
            id = 0,
            name = character.name,
            height = character.height.toIntOrNull(),
            mass = character.mass.toIntOrNull(),
            gender = character.gender,
            filmList = ListConverter.fromArrayList(character.filmList),
            created = DateConverter.dateToTimestamp(character.created),
             edited = DateConverter.dateToTimestamp(character.edited)
        )
    }

}