package com.starwars.mvvm.ui

import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.paging.PagingData
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.starwars.mvvm.adapter.CharacterAdapter
import com.starwars.mvvm.adapter.LoaderAdapter
import com.starwars.mvvm.databinding.HomeFragmentBinding
import com.starwars.mvvm.db.CharacterDB
import com.starwars.mvvm.viewModel.HomeFragmentViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class HomeFragment : Fragment() {

    @Inject
    lateinit var characterDB: CharacterDB
    private var _binding: HomeFragmentBinding? = null

    private val binding get() = _binding!!

    private lateinit var characterAdapter: CharacterAdapter

    private val viewModel: HomeFragmentViewModel by viewModels()
    private var isSearching = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = HomeFragmentBinding.inflate(inflater, container, false)

        initialization()
        setClickListener()

        getCharacter()
        getSortedCharacter()

        return binding.root
    }

    @OptIn(FlowPreview::class)
    fun onQuerySubmitted(newText: String?) {
        if (!newText.isNullOrBlank() && newText.isNotEmpty()) {
            viewModel.isSearching.value = true
            isSearching = true
            viewModel.sequence.value = newText.lowercase().trim()
            lifecycleScope.launch {
                characterAdapter.submitData(PagingData.empty())
                viewModel.getSpecificCharacter().debounce(500).collectLatest {
                    if (isSearching) {
                        characterAdapter.submitData(lifecycle, it)
                    }
                }
            }
        } else {
            viewModel.isSearching.value = false
            viewModel.sequence.value = ""
            isSearching = false
            CoroutineScope(Dispatchers.IO).launch {
                characterAdapter.submitData(PagingData.empty())
            }
        }
    }

    private fun initialization() {
        characterAdapter = CharacterAdapter()

        characterAdapter.onItemClick = { item, design, status, position: Int ->
            Log.d("apple01", "onItemClick : $status")
            when (status) {
                // Handle "edit" action
                "star" -> {

                    try {

                        val action =
                            HomeFragmentDirections.actionCharacterHomeFragmentToDetailsFragment(item)
                        findNavController().navigate(action)
                    }catch (e:Exception){

                        Log.d("test001001","${e.message}")
                    }

                }
            }}



            characterAdapter.stateRestorationPolicy =
                RecyclerView.Adapter.StateRestorationPolicy.PREVENT_WHEN_EMPTY
            _binding?.recycleview?.apply {
                val layoutManager: GridLayoutManager =
                    if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                        GridLayoutManager(activity, 3)
                    } else {
                        GridLayoutManager(activity, 2)
                    }
                this.layoutManager = layoutManager
                this.setHasFixedSize(true)
                this.adapter = characterAdapter.withLoadStateHeaderAndFooter(
                    header = LoaderAdapter(),
                    footer = LoaderAdapter()
                )
            }
        }

        private fun setClickListener() {
            binding.searchBox.setOnCloseListener {
                binding.searchBox.isFocusable = false
                isSearching = false
                CoroutineScope(Dispatchers.IO).launch {
                    characterAdapter.submitData(PagingData.empty())
                    getCharacter()
                }
                true
            }
            binding.filter.setOnClickListener {
                BottomSheetFragment(viewModel).show(childFragmentManager, "")
            }

            binding.searchBox.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(newText: String?): Boolean {
                    onQuerySubmitted(newText)
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return true
                }
            })
        }

        private fun getCharacter() {
            lifecycleScope.launch {
                viewModel.list.collectLatest {
                    if (!isSearching && viewModel.isSorting.value == false) {
                        characterAdapter.submitData(lifecycle, it)
                    }
                }
            }
        }

        private fun getSortedCharacter() {
            viewModel.isSorting.observe(viewLifecycleOwner) { status ->
                if (status) {
                    lifecycleScope.launch {
                        characterAdapter.submitData(PagingData.empty())
                        viewModel.getSortedCharacter().collectLatest {
                            if (!isSearching) {
                                characterAdapter.submitData(lifecycle, it)
                            }
                        }
                    }
                }
            }
        }


        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }
    }
