package com.starwars.mvvm.di

import android.content.Context
import androidx.room.Room
import com.starwars.mvvm.db.CharacterDB
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class DatabaseModule {

    @Singleton
    @Provides
    fun provideCharacterDB(@ApplicationContext context: Context): CharacterDB {
        return Room.databaseBuilder(
            context = context,
            klass = CharacterDB::class.java,
            name = "STAR_DB1"
        ).build()
    }
}
