package com.starwars.mvvm.db.entity

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.starwars.mvvm.constant.ListConverter
import kotlinx.parcelize.Parcelize


@Parcelize
@Entity
data class CharacterEntity(
    @PrimaryKey
    var id: Int,
    val name : String,
    val height: Int?,
    val mass: Int?,
    val gender: String?,
    val created: Long?,
    val edited: Long?,
    @TypeConverters(ListConverter::class)
    val filmList: String
) : Parcelable
