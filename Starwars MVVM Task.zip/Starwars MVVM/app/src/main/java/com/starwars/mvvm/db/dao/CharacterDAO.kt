package com.starwars.mvvm.db.dao

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.starwars.mvvm.db.entity.CharacterEntity

@Dao
interface CharacterDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: List<CharacterEntity>)

    @Query("SELECT * FROM CharacterEntity WHERE name LIKE  '%' || :sequence || '%' ORDER BY id")
    fun getSpecifcCharacters(sequence : String) : PagingSource<Int,CharacterEntity>

    @Query("SELECT * FROM CharacterEntity")
    fun getCharacters() : PagingSource<Int,CharacterEntity>

    @Query("SELECT * FROM CharacterEntity ORDER BY name ASC")
    fun getSortedCharactersByNameAsc() : PagingSource<Int,CharacterEntity>

    @Query("SELECT * FROM CharacterEntity ORDER BY name DESC")
    fun getSortedCharactersByNameDesc() : PagingSource<Int,CharacterEntity>


    @Query("SELECT * FROM CharacterEntity ORDER BY gender")
    fun getSortedCharactersByGender() : PagingSource<Int,CharacterEntity>

    @Query("SELECT * FROM CharacterEntity ORDER BY created")
    fun getSortedCharactersByCreated() : PagingSource<Int,CharacterEntity>

    @Query("SELECT * FROM CharacterEntity ORDER BY edited")
    fun getSortedCharactersByUpdated() : PagingSource<Int,CharacterEntity>

    @Query("DELETE FROM CharacterEntity")
    suspend fun deleteAllCharacter()
}