package com.starwars.mvvm.network

import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.starwars.mvvm.db.CharacterDB
import com.starwars.mvvm.db.entity.CharacterEntity
import com.starwars.mvvm.modal.Film
import com.starwars.mvvm.modal.Result
import com.starwars.mvvm.paging.CharacterRemoteMediator
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class CharacterRepo @Inject constructor(private val apiService: ApiService, private val characterDB: CharacterDB, private val remoteDataSource: RemoteDataSource) : BaseDataSource() {

    @OptIn(ExperimentalPagingApi::class)
    fun getCharacter() = Pager(
        config = PagingConfig(pageSize = 20, maxSize = 100),
        remoteMediator = CharacterRemoteMediator(apiService,characterDB),
        pagingSourceFactory = { characterDB.getCharacterDao().getCharacters()}
    ).flow

    @OptIn(ExperimentalPagingApi::class)
    fun getSpecifCharacter(something: String) = Pager(
        config = PagingConfig(pageSize = 20, maxSize = 100),
        pagingSourceFactory = { characterDB.getCharacterDao().getSpecifcCharacters(something) }
    ).flow

    suspend fun getFilm(movieId: Int) : Result<Film> =
        remoteDataSource.getfilmsDetails(movieId)

    fun getSortedCharacter(type: Int): Flow<PagingData<CharacterEntity>> {
        return Pager(
            config = PagingConfig(pageSize = 20, maxSize = 100),
            pagingSourceFactory = { when(type){
                0 ->{
                    characterDB.getCharacterDao().getSortedCharactersByNameAsc()
                }
                1 ->{
                    characterDB.getCharacterDao().getSortedCharactersByNameDesc()
                }
                2 ->{
                    characterDB.getCharacterDao().getSortedCharactersByGender()
                }
                3 ->{
                    characterDB.getCharacterDao().getSortedCharactersByCreated()
                }
                4 ->{
                    characterDB.getCharacterDao().getSortedCharactersByUpdated()
                }
                else->{
                    characterDB.getCharacterDao().getSortedCharactersByUpdated()
                }
            } }
        ).flow
    }

}