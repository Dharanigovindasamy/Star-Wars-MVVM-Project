package com.starwars.mvvm.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.starwars.mvvm.R
import com.starwars.mvvm.modal.Filter

class SortAdapter(private val filters: List<Filter>, private val clickListener: SortClickedListener) :
    RecyclerView.Adapter<SortAdapter.SortViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SortViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemView = layoutInflater.inflate(R.layout.filter_dialog_item, parent, false)
        return SortViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: SortViewHolder, position: Int) {
        val item = filters[position]
        holder.bind(item, clickListener)
    }

    override fun getItemCount(): Int {
        return filters.size
    }

    class SortViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val rightArrow: ImageView = itemView.findViewById(R.id.rightArrow)
        private val sortFilterTextView: TextView = itemView.findViewById(R.id.sortFilterTextView)

        fun bind(filter: Filter, clickListener: SortClickedListener) {
            sortFilterTextView.text = filter.name
            itemView.setOnClickListener { clickListener.onClick(filter) }
        }
    }

    class SortClickedListener(val onItemClick: (filter: Filter) -> Unit) {
        fun onClick(filter: Filter) = onItemClick(filter)
    }

}
