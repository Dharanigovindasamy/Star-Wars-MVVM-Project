package com.starwars.mvvm.modal

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Filter (
    var id:Int,
    var name: String,
    var isSelected: Boolean = false
):Parcelable