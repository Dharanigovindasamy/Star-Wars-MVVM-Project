package com.starwars.mvvm.constant

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.starwars.mvvm.modal.Filter
import java.lang.reflect.Type


object ListConverter {
    @TypeConverter
    fun fromString(value: String?): List<String> {
        val listType: Type = object : TypeToken<ArrayList<String?>?>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromArrayList(list: List<String?>?): String {
        val gson = Gson()
        return gson.toJson(list)
    }

    val filterList = mutableListOf(
        Filter(0,"Name by Asc",false),
        Filter(1,"Name by Desc",false),
        Filter(2,"Gender",false),
        Filter(3,"Created",false),
        Filter(4,"Updated",false)
    )
}